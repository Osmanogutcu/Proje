# Environment Variables Rehberi

Bu dosya, proje için gerekli environment variable'ları listeler.

## Railway.app'de Otomatik Sağlanan Değişkenler

Railway.app aşağıdaki değişkenleri otomatik olarak sağlar:
- `DATABASE_URL`: PostgreSQL bağlantı string'i (otomatik)
- `PORT`: Uygulama portu (otomatik)

## Manuel Eklenmesi Gereken Değişkenler

Railway.app dashboard'unda web servisinizin **"Variables"** sekmesine gidip aşağıdaki değişkenleri ekleyin:

### Zorunlu Değişkenler

```bash
JWT_SECRET=<güçlü_rastgele_string_oluşturun>
ADMIN_USERNAME=admin
ADMIN_PASSWORD=<güçlü_şifre_oluşturun>
```

### Opsiyonel Değişkenler

```bash
# Uygulama Ayarları
DETECTION_RADIUS_METERS=50
ADMIN_EMAIL=admin@example.com
JWT_EXPIRE_MIN=1440
OTP_TTL_SECONDS=300
OTP_CODE_LEN=6
PENALTY_COOLDOWN_SEC=180
RATE_LIMIT_WINDOW_SEC=10
RATE_LIMIT_MAX_REQ=10

# SMTP (Email bildirimleri için - opsiyonel)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Twilio (SMS OTP için - opsiyonel)
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_FROM_NUMBER=+1234567890
TWILIO_MESSAGING_SERVICE_SID=your_messaging_service_sid
```

## Local Development için .env Dosyası

Local development için proje root'unda `.env` dosyası oluşturun:

```bash
# Database Configuration
POSTGRES_USER=postgres
POSTGRES_PASSWORD=your_secure_password_here
POSTGRES_DB=tracker_db
POSTGRES_PORT=5432

# Application Settings
DETECTION_RADIUS_METERS=50
ADMIN_EMAIL=admin@example.com
ADMIN_USERNAME=admin
ADMIN_PASSWORD=changeme_secure_password

# JWT Configuration
JWT_SECRET=change_this_to_a_very_secure_random_string
JWT_ALG=HS256
JWT_EXPIRE_MIN=1440
OTP_TTL_SECONDS=300
OTP_CODE_LEN=6

# Rate Limiting
PENALTY_COOLDOWN_SEC=180
RATE_LIMIT_WINDOW_SEC=10
RATE_LIMIT_MAX_REQ=10

# SMTP Configuration (for email notifications)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password

# Twilio Configuration (for SMS OTP)
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_FROM_NUMBER=+1234567890
TWILIO_MESSAGING_SERVICE_SID=your_messaging_service_sid

# Port (Railway sets this automatically, only needed for local)
PORT=8000
```

## Güvenlik Notları

1. **JWT_SECRET**: En az 32 karakter uzunluğunda rastgele bir string kullanın
2. **ADMIN_PASSWORD**: Güçlü bir şifre kullanın (en az 12 karakter, büyük/küçük harf, sayı, özel karakter)
3. **Database Şifreleri**: Railway otomatik olarak güvenli şifreler oluşturur
4. **API Keys**: Twilio ve SMTP bilgilerini asla kod içine yazmayın, sadece environment variables kullanın

