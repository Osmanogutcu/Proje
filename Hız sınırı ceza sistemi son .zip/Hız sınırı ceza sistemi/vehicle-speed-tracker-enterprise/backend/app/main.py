import os, math, smtplib, json, time, io, csv
import random, string
from email.message import EmailMessage
from fastapi import FastAPI, Request, BackgroundTasks, HTTPException, Depends, WebSocket, WebSocketDisconnect, Response, Body
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from datetime import datetime, timedelta, date, timezone
import asyncio
import asyncpg
import httpx

from jose import jwt, JWTError
from passlib.context import CryptContext
from typing import Dict, Optional, List
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from twilio.rest import Client as TwilioClient

OVERPASS_URLS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://overpass.openstreetmap.fr/api/interpreter",
]

# === NEW: config ===
JWT_SECRET = os.getenv("JWT_SECRET", "change_this_device_secret")
JWT_ALG = os.getenv("JWT_ALG", "HS256")
OTP_TTL_SECONDS = int(os.getenv("OTP_TTL_SECONDS", "300"))
OTP_CODE_LEN = int(os.getenv("OTP_CODE_LEN", "6"))


def now_utc():
    return datetime.now(timezone.utc)


def gen_otp(n: int) -> str:
    return "".join(random.choice(string.digits) for _ in range(n))


def issue_device_token(device_id: str) -> str:
    payload = {
        "sub": device_id,
        "type": "device",
        "iat": int(now_utc().timestamp()),
        "exp": int((now_utc() + timedelta(hours=1)).timestamp())
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def verify_device_token(token: str, device_id: Optional[str] = None) -> bool:
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
        if payload.get("type") != "device":
            return False
        if device_id and payload.get("sub") != device_id:
            return False
        return True
    except Exception:
        return False


async def send_sms(phone: str, body: str):
    # Twilio bağlarsan burada kullan; yoksa logla
    sid = os.getenv("TWILIO_ACCOUNT_SID")
    tok = os.getenv("TWILIO_AUTH_TOKEN")
    from_no = os.getenv("TWILIO_FROM_NUMBER")
    msg_svc = os.getenv("TWILIO_MESSAGING_SERVICE_SID")  # optional

    if not sid or not tok:
        # Twilio yoksa fallback: logla ve return False
        print(f"[SMS-FALLBACK] Twilio credentials missing. SMS to {phone}: {body}")
        return False

    try:
        client = TwilioClient(sid, tok)
        send_kwargs = {"to": phone}
        if msg_svc:
            send_kwargs["messaging_service_sid"] = msg_svc
        else:
            send_kwargs["from_"] = from_no

        message = client.messages.create(body=body, **send_kwargs)
        print(f"[SMS] sent to {phone} sid={message.sid} status={message.status}")
        return True
    except Exception as e:
        print(f"[SMS ERROR] to={phone} error={e}")
        return False


def kmh_from_ms(ms):
    if ms is None:
        return None
    return ms * 3.6


app = FastAPI()
app.mount("/static", StaticFiles(directory="/app/frontend"), name="static")

# ENV
# Railway.app provides DATABASE_URL, fallback to docker-compose format
DATABASE_URL = os.getenv('DATABASE_URL')
if DATABASE_URL:
    # Railway provides DATABASE_URL in format: postgresql://user:pass@host:port/dbname
    DB_DSN = DATABASE_URL
else:
    # Fallback for local docker-compose
    DB_DSN = f"postgresql://{os.getenv('POSTGRES_USER','postgres')}:{os.getenv('POSTGRES_PASSWORD','postgres')}@db:{os.getenv('POSTGRES_PORT','5432')}/{os.getenv('POSTGRES_DB','tracker_db')}"
DETECTION_RADIUS = int(os.getenv('DETECTION_RADIUS_METERS','50'))
ADMIN_EMAIL = os.getenv('ADMIN_EMAIL','admin@example.com')
SMTP_HOST = os.getenv('SMTP_HOST','')
SMTP_PORT = int(os.getenv('SMTP_PORT','587') or 587)
SMTP_USER = os.getenv('SMTP_USER','')
SMTP_PASS = os.getenv('SMTP_PASS','')
JWT_SECRET = os.getenv('JWT_SECRET','change')
JWT_EXPIRE_MIN = int(os.getenv('JWT_EXPIRE_MIN','1440'))
ADMIN_USERNAME = os.getenv('ADMIN_USERNAME','admin')
ADMIN_PASSWORD = os.getenv('ADMIN_PASSWORD','changeme')
PENALTY_COOLDOWN_SEC = int(os.getenv('PENALTY_COOLDOWN_SEC','180'))
RATE_LIMIT_WINDOW_SEC = int(os.getenv('RATE_LIMIT_WINDOW_SEC','10'))
RATE_LIMIT_MAX_REQ = int(os.getenv('RATE_LIMIT_MAX_REQ','10'))
TWILIO_SID = os.getenv('TWILIO_ACCOUNT_SID','')
TWILIO_TOKEN = os.getenv('TWILIO_AUTH_TOKEN','')
TWILIO_FROM = os.getenv('TWILIO_FROM_NUMBER','')

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Global
pool = None
zones_cache = {"etag":"", "data": [], "ts": 0}
cooldowns: Dict[str, float] = {}  # device:zone -> last penalty time
rate_buckets: Dict[str, list] = {}  # key: device/ip -> ts list
ws_clients: Dict[str, set] = {}     # device_id -> websockets set


def now_ts():
    return time.time()


async def get_pool():
    global pool
    if pool is None:
        pool = await asyncpg.create_pool(dsn=DB_DSN, min_size=1, max_size=10)
    return pool


def create_jwt(payload: dict, minutes: int = JWT_EXPIRE_MIN):
    to_encode = payload.copy()
    to_encode["exp"] = datetime.utcnow() + timedelta(minutes=minutes)
    return jwt.encode(to_encode, JWT_SECRET, algorithm="HS256")


def verify_jwt(token: str) -> dict:
    try:
        return jwt.decode(token, JWT_SECRET, algorithms=["HS256"])
    except JWTError as e:
        raise HTTPException(status_code=401, detail="Invalid token")


async def send_penalty_email(device_id, sp, speed, ts):
    if not SMTP_HOST:
        print("SMTP not configured; skipping email")
        return
    msg = EmailMessage()
    msg['Subject'] = f"Speed penalty: {device_id} exceeded limit at {sp['name']}"
    msg['From'] = SMTP_USER
    msg['To'] = ADMIN_EMAIL
    body = f"Device {device_id} exceeded speed limit {sp['speed_limit']} km/h at {sp['name']} (id={sp['id']}).\nRecorded speed: {speed}\nTime: {ts}"
    msg.set_content(body)
    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=10) as s:
            s.starttls(); s.login(SMTP_USER, SMTP_PASS); s.send_message(msg)
            print('Email sent')
    except Exception as e:
        print('Failed sending email:', e)


async def load_zones(force=False):
    if not force and (now_ts() - zones_cache["ts"] < 5):
        return zones_cache["data"]
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT id, name, speed_limit, radius_meters, ST_Y(geom::geometry) AS lat, ST_X(geom::geometry) AS lon FROM speed_points ORDER BY id")
        data = [dict(r) for r in rows]
    etag = f"{len(data)}-{data[-1]['id'] if data else 0}"
    zones_cache.update({"etag": etag, "data": data, "ts": now_ts()})
    return data


def rate_limited(key: str) -> bool:
    bucket = rate_buckets.setdefault(key, [])
    t = now_ts()
    cutoff = t - RATE_LIMIT_WINDOW_SEC
    while bucket and bucket[0] < cutoff:
        bucket.pop(0)
    if len(bucket) >= RATE_LIMIT_MAX_REQ:
        return True
    bucket.append(t)
    return False


# --- Schemas ---
class TrackPayload(BaseModel):
    device_id: str
    lat: float
    lon: float
    speed: Optional[float] = None
    timestamp: Optional[str] = None


class LoginPayload(BaseModel):
    username: str
    password: str


class DeviceLoginPayload(BaseModel):
    device_id: str


class OTPRequestPayload(BaseModel):
    device_id: str
    phone_number: str


class OTPVerifyPayload(BaseModel):
    device_id: str
    code: str


class ZonePayload(BaseModel):
    name: str
    lat: float
    lon: float
    speed_limit: int
    radius_meters: int = 50


class DevicePayload(BaseModel):
    device_id: str
    phone_number: Optional[str] = None


class OSMImportRequest(BaseModel):
    country: str = "Turkey"            # Alternatif 1: alan adı (area)
    bbox: Optional[list[float]] = None # Alternatif 2: [south, west, north, east]
    default_speed: int = 50
    default_radius: int = 50
    name_prefix: str = "OSM Cam"
    upsert: bool = True


class OTPReq(BaseModel):
    device_id: str
    phone: str


@app.post("/api/device/request_otp")
async def device_request_otp(req: OTPReq = Body(...), request: Request = None):
    # Teşhis amaçlı: body hiç gelmiyorsa logla
    if request is not None:
        try:
            raw = await request.body()
            if not raw:
                print("[DEBUG] request.body() is empty")
            else:
                print(f"[DEBUG] raw body bytes len={len(raw)}")
        except Exception as e:
            print(f"[DEBUG] body read error: {e}")

    pool = await get_pool()
    code = gen_otp(OTP_CODE_LEN)
    expires = now_utc() + timedelta(seconds=OTP_TTL_SECONDS)
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO device_otps(device_id, phone, code, expires_at)
            VALUES ($1,$2,$3,$4)
            ON CONFLICT (device_id) DO UPDATE
            SET phone=EXCLUDED.phone, code=EXCLUDED.code, expires_at=EXCLUDED.expires_at
        """, req.device_id, req.phone, code, expires)
    await send_sms(req.phone, f"Giris kodunuz: {code}")
    return {"ok": True, "ttl": OTP_TTL_SECONDS}


class OTPVerify(BaseModel):
    device_id: str
    code: str


class Telemetry(BaseModel):
    device_id: str
    lat: float
    lon: float
    speed: Optional[float] = None   # m/s gelebilir
    ts: Optional[str] = None
    source: Optional[str] = "gps"


# 3.1: Telefon IP eşleme için payload
class WhoAmIPayload(BaseModel):
    device_id: str


# 3.1: Telefonun IP’sini cihazla eşleştiren endpoint
@app.post("/api/device/whoami")
async def device_whoami(payload: WhoAmIPayload, request: Request):
    # Nginx X-Forwarded-For gönderiyorsa onu al, yoksa doğrudan client IP
    xff = request.headers.get("x-forwarded-for")
    if xff:
        client_ip = xff.split(",")[0].strip()
    else:
        client_ip = request.client.host

    ua = request.headers.get("user-agent", "")

    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO device_ips(device_id, ip, ua)
            VALUES ($1, $2::inet, $3)
            ON CONFLICT DO NOTHING
        """, payload.device_id, client_ip, ua)
        await conn.execute("""
            UPDATE device_ips
            SET last_seen = now()
            WHERE device_id = $1 AND ip = $2::inet
        """, payload.device_id, client_ip)

    return {"ok": True, "device_id": payload.device_id, "ip": client_ip}


# --- Startup ---
@app.on_event("startup")
async def startup():
    await get_pool()
    await load_zones(force=True)


# --- Pages ---
@app.get("/", response_class=HTMLResponse)
async def root():
    return FileResponse("/app/frontend/index.html")


@app.get("/admin", response_class=HTMLResponse)
async def admin_page():
    return FileResponse("/app/frontend/admin.html")


@app.get("/tracker", response_class=HTMLResponse)
async def tracker_page():
    return FileResponse("/app/frontend/tracker.html")


# --- Auth helpers ---
def require_admin(request: Request):
    auth = request.headers.get("Authorization","")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = auth.split(" ",1)[1]
    data = verify_jwt(token)
    if data.get("role")!="admin":
        raise HTTPException(status_code=403, detail="Forbidden")
    return data


def require_device(request: Request) -> str:
    auth = request.headers.get("Authorization","")
    if not auth.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing token")
    token = auth.split(" ",1)[1]
    data = verify_jwt(token)
    if data.get("role")!="device":
        raise HTTPException(status_code=403, detail="Forbidden")
    return data["device_id"]


# --- Auth endpoints ---
@app.post("/api/admin/login")
async def admin_login(payload: LoginPayload):
    if payload.username == ADMIN_USERNAME and payload.password == ADMIN_PASSWORD:
        token = create_jwt({"role":"admin","sub":payload.username})
        return {"access_token": token, "token_type":"bearer"}
    raise HTTPException(status_code=401, detail="Bad credentials")


@app.post("/api/device/request_otp")
async def device_request_otp_simple(req: OTPReq):
    pool = await get_pool()
    code = gen_otp(OTP_CODE_LEN)
    expires = now_utc() + timedelta(seconds=OTP_TTL_SECONDS)
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO device_otps(device_id, phone, code, expires_at)
            VALUES ($1,$2,$3,$4)
            ON CONFLICT (device_id) DO UPDATE
            SET phone=EXCLUDED.phone, code=EXCLUDED.code, expires_at=EXCLUDED.expires_at
        """, req.device_id, req.phone, code, expires)
    await send_sms(req.phone, f"Giris kodunuz: {code}")
    return {"ok": True, "ttl": OTP_TTL_SECONDS}


@app.post("/api/device/verify_otp")
async def device_verify_otp(req: OTPVerify):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("""
            SELECT phone, code, expires_at FROM device_otps WHERE device_id=$1
        """, req.device_id)
        if not row:
            raise HTTPException(400, "OTP not requested")
        if row["code"] != req.code:
            raise HTTPException(400, "Invalid code")
        if row["expires_at"] < now_utc():
            raise HTTPException(400, "Code expired")

        await conn.execute("""
            INSERT INTO devices(device_id, phone, verified_at)
            VALUES ($1,$2, now())
            ON CONFLICT (device_id) DO UPDATE
            SET phone=EXCLUDED.phone, verified_at=now()
        """, req.device_id, row["phone"])

        await conn.execute("DELETE FROM device_otps WHERE device_id=$1", req.device_id)

    token = issue_device_token(req.device_id)
    return {"ok": True, "device_token": token}


# 3.2: Telemetry – hız yoksa önceki noktadan hesapla
@app.post("/api/telemetry")
async def telemetry_endpoint(t: Telemetry, request: Request):
    auth = request.headers.get("authorization","")
    if not auth.startswith("Bearer "):
        raise HTTPException(401, "Missing token")
    token = auth.split(" ",1)[1]
    if not verify_device_token(token, t.device_id):
        raise HTTPException(401, "Invalid token")

    ts = t.ts or now_utc().isoformat()

    pool = await get_pool()
    async with pool.acquire() as conn:
        # Hız yoksa önceki telemetry noktasından hesapla
        speed_ms = t.speed
        if speed_ms is None:
            prev = await conn.fetchrow("""
                SELECT ts,
                       ST_Y(geom::geometry) AS lat,
                       ST_X(geom::geometry) AS lon
                FROM telemetry
                WHERE device_id=$1
                ORDER BY ts DESC
                LIMIT 1
            """, t.device_id)
            if prev:
                R = 6371000.0
                lat1 = math.radians(float(prev["lat"]))
                lon1 = math.radians(float(prev["lon"]))
                lat2 = math.radians(t.lat)
                lon2 = math.radians(t.lon)
                dlat = lat2 - lat1
                dlon = lon2 - lon1
                a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
                d = 2 * R * math.atan2(math.sqrt(a), math.sqrt(1 - a))

                t_prev = prev["ts"]
                try:
                    t_now = datetime.fromisoformat(ts)
                except Exception:
                    t_now = now_utc()
                dt_s = max((t_now - t_prev).total_seconds(), 0.1)
                speed_ms = d / dt_s
                // --- HIZ HESABI BİTTİKTEN SONRA: speedKmh elimizde ---
// speedKmh, lat, lon, device_id, ip, payload.plate, payload.phone vb. var.

(async () => {
  try {
    // 1) İlgili aracı bul (devices tablosu üzerinden)
    const deviceRes = await db.query(
      `SELECT d.id AS device_pk, v.id AS vehicle_id, v.plate
       FROM devices d
       LEFT JOIN vehicles v ON v.id = d.vehicle_id
       WHERE d.device_id = $1`,
      [device_id]
    );

    let vehicleId = null;
    let plateFromDb = payload.plate || null;

    if (deviceRes.rows.length > 0) {
      vehicleId = deviceRes.rows[0].vehicle_id;
      if (deviceRes.rows[0].plate) {
        plateFromDb = deviceRes.rows[0].plate;
      }
    }

    // 2) Noktayı geometry'e çevir
    const pointWkt = `POINT(${lon} ${lat})`;

    // 3) Bu noktaya en yakın hız bölgesini bul
    const zoneRes = await db.query(
      `SELECT id, name, speed_limit_kmh
       FROM speed_zones
       WHERE ST_DWithin(
               geom::geography,
               ST_GeogFromText($1),
               50  -- 50 metre içinde olan bölgeler
             )
       ORDER BY ST_Distance(
                 geom::geography,
                 ST_GeogFromText($1)
               )
       LIMIT 1`,
      [`SRID=4326;${pointWkt}`]
    );

    let speedLimitKmh = 82; // default
    let zoneId = null;

    if (zoneRes.rows.length > 0) {
      speedLimitKmh = zoneRes.rows[0].speed_limit_kmh;
      zoneId = zoneRes.rows[0].id;
    }

    // 4) Telemetry kaydını DB'ye insert et
    const teleRes = await db.query(
      `INSERT INTO telemetry_points
        (device_id, vehicle_id, phone, lat, lon, geom, speed_kmh, raw_ip)
       VALUES
        ($1, $2, $3, $4, $5,
         ST_SetSRID(ST_MakePoint($5, $4), 4326),
         $6, $7)
       RETURNING id`,
      [
        device_id,
        vehicleId,
        phone,
        lat,
        lon,
        speedKmh,
        ip
      ]
    );

    const telemetryId = teleRes.rows[0].id;

    // 5) İhlal var mı?
    if (speedKmh > speedLimitKmh) {
      const overSpeed = speedKmh - speedLimitKmh;

      await db.query(
        `INSERT INTO violations
          (telemetry_id, vehicle_id, device_id, plate,
           measured_speed_kmh, speed_limit_kmh, over_speed_kmh, zone_id)
         VALUES
          ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [
          telemetryId,
          vehicleId,
          device_id,
          plateFromDb,
          speedKmh,
          speedLimitKmh,
          overSpeed,
          zoneId
        ]
      );

      console.warn(">>> HIZ İHLALİ (DB'ye kaydedildi) <<<", {
        telemetryId,
        device_id,
        plate: plateFromDb,
        speed_kmh: speedKmh,
        limit: speedLimitKmh,
        over: overSpeed
      });
    }

  } catch (err) {
    console.error("[DB ERROR in /telemetry]", err);
  }
})();


        # Telemetry kaydı
        await conn.execute("""
          INSERT INTO telemetry(device_id, ts, geom, speed_m_s, source)
          VALUES ($1, $2, ST_SetSRID(ST_MakePoint($3,$4),4326)::geography, $5, $6)
        """, t.device_id, ts, t.lon, t.lat, speed_ms, t.source)

        speed_kmh = kmh_from_ms(speed_ms)
        if speed_kmh is not None:
            row = await conn.fetchrow("""
              SELECT id, name, speed_limit, radius_meters
              FROM speed_points
              WHERE ST_DWithin(geom, ST_SetSRID(ST_MakePoint($1,$2),4326)::geography, radius_meters)
                AND $3 > speed_limit
              LIMIT 1
            """, t.lon, t.lat, speed_kmh)
            if row:
                await conn.execute("""
                  INSERT INTO penalties(device_id, zone_id, speed_kmh, speed_limit, ts)
                  VALUES ($1,$2,$3,$4, now())
                """, t.device_id, row["id"], speed_kmh, row["speed_limit"])
                print(f"[PENALTY] {t.device_id} >{speed_kmh:.1f}km/h in zone {row['id']} (limit {row['speed_limit']})")

    # (Varsa) WebSocket broadcast
    try:
        await broadcast_device(t.device_id, {
            "device_id": t.device_id, "lat": t.lat, "lon": t.lon,
            "speed_kmh": speed_kmh, "ts": ts
        })
    except Exception:
        pass

    return {"ok": True}


@app.post("/api/device/login")
async def device_login(payload: DeviceLoginPayload, request: Request):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT device_id FROM devices WHERE device_id=$1", payload.device_id)
        if not row:
            ip = request.client.host if request.client else None
            await conn.execute("INSERT INTO devices(device_id,last_ip) VALUES($1,$2)", payload.device_id, ip)
        token = create_jwt({"role":"device","device_id":payload.device_id})
        return {"access_token": token, "token_type":"bearer"}


# --- SMS OTP (eski şema, admin tarafında) ---
def send_sms_sync(phone: str, body: str):
    if not (TWILIO_SID and TWILIO_TOKEN and TWILIO_FROM):
        print("[OTP] Twilio not configured; simulated send to", phone, ":", body)
        return
    cli = TwilioClient(TWILIO_SID, TWILIO_TOKEN)
    cli.messages.create(to=phone, from_=TWILIO_FROM, body=body)


@app.post("/api/device/request_otp")
async def request_otp(payload: OTPRequestPayload):
    # generate 6-digit code, store with expiry
    code = f"{int(now_ts()) % 1000000:06d}"
    exp = datetime.utcnow() + timedelta(minutes=10)
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO devices(device_id, phone_number, otp_code, otp_expires)
            VALUES($1,$2,$3,$4)
            ON CONFLICT (device_id) DO UPDATE SET phone_number=EXCLUDED.phone_number, otp_code=EXCLUDED.otp_code, otp_expires=EXCLUDED.otp_expires
        """, payload.device_id, payload.phone_number, code, exp)
    send_sms_sync(payload.phone_number, f"Your verification code: {code}")
    return {"ok": True}


@app.post("/api/device/verify_otp")
async def verify_otp(payload: OTPVerifyPayload):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT otp_code, otp_expires FROM devices WHERE device_id=$1", payload.device_id)
        if not row or not row["otp_code"]:
            raise HTTPException(status_code=400, detail="No OTP set")
        if row["otp_expires"] < datetime.utcnow():
            raise HTTPException(status_code=400, detail="OTP expired")
        if row["otp_code"] != payload.code:
            raise HTTPException(status_code=400, detail="Invalid code")
        await conn.execute("UPDATE devices SET phone_verified=TRUE, otp_code=NULL, otp_expires=NULL WHERE device_id=$1", payload.device_id)
    return {"ok": True}


# --- Admin APIs ---
@app.get("/api/admin/zones")
async def admin_list_zones(request: Request):
    require_admin(request)
    return await load_zones(force=True)


@app.post("/api/admin/zones")
async def admin_add_zone(payload: ZonePayload, request: Request):
    require_admin(request)
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO speed_points(name, geom, speed_limit, radius_meters) VALUES($1, ST_SetSRID(ST_MakePoint($2,$3),4326)::geography, $4, $5)",
                           payload.name, payload.lon, payload.lat, payload.speed_limit, payload.radius_meters)
    await load_zones(force=True)
    return {"ok": True}


@app.delete("/api/admin/zones/{zone_id}")
async def admin_del_zone(zone_id: int, request: Request):
    require_admin(request)
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM speed_points WHERE id=$1", zone_id)
    await load_zones(force=True)
    return {"ok": True}


@app.post("/api/admin/devices")
async def admin_add_device(payload: DevicePayload, request: Request):
    require_admin(request)
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO devices(device_id,phone_number) VALUES($1,$2) ON CONFLICT (device_id) DO UPDATE SET phone_number=EXCLUDED.phone_number",
                           payload.device_id, payload.phone_number)
    return {"ok": True}


@app.get("/api/admin/penalties")
async def admin_penalties(request: Request):
    require_admin(request)
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT p.id,p.device_id,p.recorded_speed,p.recorded_at,sp.name as zone_name FROM penalties p LEFT JOIN speed_points sp ON sp.id=p.speed_point_id ORDER BY p.recorded_at DESC LIMIT 500")
        return [dict(r) for r in rows]


OVERPASS_URL = "https://overpass-api.de/api/interpreter"


def _parse_maxspeed(v: str) -> int | None:
    """OSM maxspeed: '50', '50 km/h', 'urban', 'signals' gibi değerler gelebilir; mümkün olduğunca sayıya çevir."""
    if not v:
        return None
    v = v.strip().lower()
    # en yaygın durum: '50' veya '50 km/h'
    for tok in v.replace("km/h", "").split():
        if tok.isdigit():
            try:
                return int(tok)
            except:
                pass
    return None


async def _fetch_overpass(country: str = "Turkey", bbox: Optional[list[float]] = None) -> list[dict]:
    """
    Eğer bbox verilirse onu kullanır: [south, west, north, east]
    Aksi halde area[name][boundary=administrative] ile ülke/şehir alanını kullanır.
    """
    if bbox and len(bbox) == 4:
        s, w, n, e = bbox
        query = f"""
        [out:json][timeout:120];
        (
          node["highway"="speed_camera"]({s},{w},{n},{e});
        );
        out body qt;
        """
    else:
        query = f"""
        [out:json][timeout:120];
        area[boundary="administrative"][name~"{country}",i]->.a;
        (
          node["highway"="speed_camera"](area.a);
        );
        out body qt;
        """

    async with httpx.AsyncClient(timeout=120) as client:
        resp = await client.post(OVERPASS_URL, data={"data": query})
        resp.raise_for_status()
        data = resp.json()
        return data.get("elements", [])


@app.post("/api/admin/import/osm")
async def admin_import_osm(req: OSMImportRequest, request: Request):
    require_admin(request)

    elems = await _fetch_overpass(req.country, req.bbox)
    if not elems:
        return {"ok": False, "message": "Overpass boş döndü"}

    pool = await get_pool()
    inserted = 0
    skipped = 0

    async with pool.acquire() as conn:
        tr = conn.transaction()
        await tr.start()
        try:
            for e in elems:
                if e.get("type") != "node":
                    continue
                lat = e.get("lat"); lon = e.get("lon")
                if lat is None or lon is None:
                    continue
                tags = e.get("tags", {}) or {}
                nm = tags.get("name") or f"{req.name_prefix} #{e.get('id')}"
                ms_raw = tags.get("maxspeed")
                spd = _parse_maxspeed(ms_raw) if ms_raw else None
                limit = spd or req.default_speed
                radius = req.default_radius

                if req.upsert:
                    exists = await conn.fetchval("""
                        SELECT 1
                        FROM speed_points
                        WHERE speed_limit = $1
                          AND ST_DWithin(geom, ST_SetSRID(ST_MakePoint($2,$3),4326)::geography, 3)
                        LIMIT 1
                    """, limit, lon, lat)
                    if exists:
                        skipped += 1
                        continue

                await conn.execute("""
                    INSERT INTO speed_points(name, geom, speed_limit, radius_meters)
                    VALUES ($1,
                            ST_SetSRID(ST_MakePoint($2,$3),4326)::geography,
                            $4, $5)
                """, nm, lon, lat, limit, radius)
                inserted += 1

            await tr.commit()
        except Exception as ex:
            await tr.rollback()
            raise HTTPException(status_code=500, detail=f"Import hata: {ex}")

    await load_zones(force=True)
    return {"ok": True, "inserted": inserted, "skipped": skipped, "total_raw": len(elems)}


# --- Public APIs ---
@app.get("/api/zones")
async def api_zones(etag: Optional[str] = None):
    data = await load_zones()
    if etag and etag == zones_cache["etag"]:
        return JSONResponse(status_code=304, content={})
    return JSONResponse(headers={"ETag": zones_cache["etag"]}, content=data)


@app.get("/api/latest/{device_id}")
async def api_latest(device_id: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT device_id, ST_Y(geom::geometry) AS lat, ST_X(geom::geometry) AS lon, speed, ts FROM track_points WHERE device_id=$1 ORDER BY created_at DESC LIMIT 1", device_id)
        if not row:
            raise HTTPException(status_code=404, detail="No data")
        return dict(row)


@app.get("/api/penalties")
async def api_penalties():
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT p.id,p.device_id,p.recorded_speed,p.recorded_at,sp.name as zone_name FROM penalties p LEFT JOIN speed_points sp ON sp.id=p.speed_point_id ORDER BY p.recorded_at DESC LIMIT 200")
        return [dict(r) for r in rows]


# --- Tracking (PostGIS proximity) ---
async def ws_notify(device_id: str, payload: dict):
    conns = ws_clients.get(device_id, set())
    to_remove = set()
    for ws in conns:
        try:
            await ws.send_text(json.dumps(payload))
        except Exception:
            to_remove.add(ws)
    if to_remove:
        conns -= to_remove
        ws_clients[device_id] = conns


@app.post("/track")
async def track(payload: TrackPayload, request: Request, background_tasks: BackgroundTasks):
    key = request.client.host if request.client else payload.device_id
    if rate_limited(key):
        raise HTTPException(status_code=429, detail="Too many requests")

    device_id_from_token = require_device(request)
    if device_id_from_token != payload.device_id:
        raise HTTPException(status_code=400, detail="device_id mismatch")

    pool = await get_pool()
    ts = payload.timestamp or datetime.utcnow().isoformat()
    lat, lon = payload.lat, payload.lon
    async with pool.acquire() as conn:
        await conn.execute("INSERT INTO track_points(device_id, geom, speed, ts) VALUES($1, ST_SetSRID(ST_MakePoint($2,$3),4326)::geography, $4, $5)",
                           payload.device_id, lon, lat, payload.speed, ts)
        await conn.execute("INSERT INTO devices(device_id,last_ip) VALUES($1,$2) ON CONFLICT(device_id) DO UPDATE SET last_ip=EXCLUDED.last_ip",
                           payload.device_id, request.client.host if request.client else None)
        rows = await conn.fetch("""
            SELECT id, name, speed_limit, radius_meters
            FROM speed_points
            WHERE ST_DWithin(geom, ST_SetSRID(ST_MakePoint($1,$2),4326)::geography, radius_meters)
        """, lon, lat)
        for r in rows:
            spd = float(payload.speed) if payload.speed is not None else None
            if spd is None:
                continue
            if spd > r['speed_limit']:
                key_cd = f"{payload.device_id}:{r['id']}"
                last = cooldowns.get(key_cd, 0.0)
                if now_ts() - last >= PENALTY_COOLDOWN_SEC:
                    await conn.execute(
                        "INSERT INTO penalties(device_id,speed_point_id,recorded_speed,recorded_at,note) VALUES($1,$2,$3,$4,$5)",
                        payload.device_id, r['id'], spd, ts, f"Exceeded by {spd - r['speed_limit']} km/h"
                    )
                    cooldowns[key_cd] = now_ts()
                    background_tasks.add_task(send_penalty_email, payload.device_id, {"id":r['id'], "name":r['name'], "speed_limit":r['speed_limit']}, spd, ts)
                    await ws_notify(payload.device_id, {"type":"penalty","zone":{"id":r['id'],"name":r['name'],"speed_limit":r['speed_limit']}, "speed":spd, "ts":ts})
                    return {"status":"penalty","zone":dict(r)}

    await ws_notify(payload.device_id, {"type":"position","lat":lat,"lon":lon,"speed":payload.speed,"ts":ts})
    return {"status":"ok"}


# --- WebSocket ---
@app.websocket("/ws/{device_id}")
async def ws_track(websocket: WebSocket, device_id: str):
    await websocket.accept()
    ws_clients.setdefault(device_id, set()).add(websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        ws_clients.get(device_id, set()).discard(websocket)


# --- Reports (CSV/PDF) ---
def _daterange(days: int):
    end = datetime.utcnow().date()
    start = end - timedelta(days=days-1)
    return start, end


async def _fetch_penalties(start: date, end: date) -> List[dict]:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT p.id, p.device_id, p.recorded_speed, p.recorded_at::date as day, sp.name as zone_name
            FROM penalties p LEFT JOIN speed_points sp ON sp.id=p.speed_point_id
            WHERE p.recorded_at::date BETWEEN $1 AND $2
            ORDER BY p.recorded_at DESC
        """, start, end)
        return [dict(r) for r in rows]


def _csv_response(rows: List[dict], filename: str):
    fp = io.StringIO()
    import csv as _csv
    w = _csv.DictWriter(fp, fieldnames=["id","device_id","recorded_speed","day","zone_name"])
    w.writeheader()
    for r in rows: w.writerow(r)
    mem = io.BytesIO(fp.getvalue().encode("utf-8"))
    return StreamingResponse(mem, media_type="text/csv", headers={"Content-Disposition": f"attachment; filename={filename}"})


def _pdf_response(rows: List[dict], title: str, filename: str):
    mem = io.BytesIO()
    c = canvas.Canvas(mem, pagesize=A4)
    width, height = A4
    y = height - 50
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, y, title); y -= 20
    c.setFont("Helvetica", 10)
    headers = ["ID","Device","Speed","Day","Zone"]
    c.drawString(40, y, " | ".join(headers)); y -= 15
    for r in rows:
        line = f"{r['id']} | {r['device_id']} | {r['recorded_speed']} | {r['day']} | {r['zone_name']}"
        if y < 60:
            c.showPage(); y = height - 50
        c.drawString(40, y, line); y -= 12
    c.showPage(); c.save()
    mem.seek(0)
    return StreamingResponse(mem, media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename={filename}"})


@app.get("/api/admin/report/daily.csv")
async def report_daily_csv(request: Request):
    require_admin(request)
    start, end = _daterange(1)
    rows = await _fetch_penalties(start, end)
    return _csv_response(rows, "penalties_daily.csv")


@app.get("/api/admin/report/weekly.csv")
async def report_weekly_csv(request: Request):
    require_admin(request)
    start, end = _daterange(7)
    rows = await _fetch_penalties(start, end)
    return _csv_response(rows, "penalties_weekly.csv")


@app.get("/api/admin/report/daily.pdf")
async def report_daily_pdf(request: Request):
    require_admin(request)
    start, end = _daterange(1)
    rows = await _fetch_penalties(start, end)
    return _pdf_response(rows, "Daily Penalties", "penalties_daily.pdf")


@app.get("/api/admin/report/weekly.pdf")
async def report_weekly_pdf(request: Request):
    require_admin(request)
    start, end = _daterange(7)
    rows = await _fetch_penalties(start, end)
    return _pdf_response(rows, "Weekly Penalties", "penalties_weekly.pdf")
