-- Enable PostGIS
CREATE EXTENSION IF NOT EXISTS postgis;

-- Tables (with PostGIS geography points)
CREATE TABLE IF NOT EXISTS devices (
  id SERIAL PRIMARY KEY,
  device_id TEXT UNIQUE NOT NULL,
  phone_number TEXT,
  phone_verified BOOLEAN DEFAULT FALSE,
  otp_code TEXT,
  otp_expires TIMESTAMP,
  last_ip TEXT,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS speed_points (
  id SERIAL PRIMARY KEY,
  name TEXT,
  geom geography(Point,4326) NOT NULL,
  speed_limit INTEGER NOT NULL,
  radius_meters INTEGER DEFAULT 50,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS track_points (
  id SERIAL PRIMARY KEY,
  device_id TEXT NOT NULL,
  geom geography(Point,4326) NOT NULL,
  speed DOUBLE PRECISION,
  ts TIMESTAMP,
  created_at TIMESTAMP DEFAULT now()
);

CREATE TABLE IF NOT EXISTS penalties (
  id SERIAL PRIMARY KEY,
  device_id TEXT NOT NULL,
  speed_point_id INTEGER REFERENCES speed_points(id) ON DELETE SET NULL,
  recorded_speed DOUBLE PRECISION,
  recorded_at TIMESTAMP DEFAULT now(),
  note TEXT
);

-- Indexes (GiST for geography)
CREATE INDEX IF NOT EXISTS idx_speed_points_geom ON speed_points USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_track_points_geom ON track_points USING GIST (geom);
CREATE INDEX IF NOT EXISTS idx_track_device_time ON track_points(device_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_penalties_time ON penalties(recorded_at DESC);

-- Seed example zone (Izmir Konak)
INSERT INTO speed_points(name, geom, speed_limit, radius_meters)
VALUES ('Example Zone 1', ST_GeogFromText('SRID=4326;POINT(27.142826 38.423734)'), 50, 50)
ON CONFLICT DO NOTHING;
