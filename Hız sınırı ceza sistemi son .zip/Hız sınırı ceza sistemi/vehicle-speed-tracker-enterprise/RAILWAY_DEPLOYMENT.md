# Railway.app Deployment Rehberi

Bu rehber, Vehicle Speed Tracker Enterprise projesini Railway.app'e deploy etmek için adım adım talimatlar içerir.

## 📋 Ön Hazırlık

### 1. Railway.app Hesabı Oluşturma
- [Railway.app](https://railway.app) adresine gidin
- GitHub hesabınızla giriş yapın (önerilir) veya email ile kayıt olun
- Yeni bir proje oluşturun

### 2. GitHub Repository Hazırlığı
- Projenizi GitHub'a push edin (eğer henüz yapmadıysanız)
- Railway, GitHub repository'nizi otomatik olarak bağlayabilir

## 🚀 Railway.app'de Deployment Adımları

### Adım 1: Yeni Proje Oluşturma

1. Railway.app dashboard'a gidin
2. **"New Project"** butonuna tıklayın
3. **"Deploy from GitHub repo"** seçeneğini seçin
4. Repository'nizi seçin ve bağlayın

### Adım 2: PostgreSQL Veritabanı Ekleme

1. Proje dashboard'unda **"+ New"** butonuna tıklayın
2. **"Database"** → **"Add PostgreSQL"** seçin
3. Railway otomatik olarak PostgreSQL servisi oluşturacak
4. **ÖNEMLİ**: PostgreSQL servisini seçin ve **"Variables"** sekmesine gidin
5. `DATABASE_URL` değişkeninin otomatik oluşturulduğunu kontrol edin
6. Bu değişken otomatik olarak web servisinize bağlanacak

### Adım 3: Web Servisi Oluşturma

1. Proje dashboard'unda **"+ New"** butonuna tıklayın
2. **"GitHub Repo"** seçin ve repository'nizi seçin
3. Railway otomatik olarak `railway.json` dosyasını algılayacak

### Adım 4: Environment Variables Ayarlama

Web servisinizi seçin ve **"Variables"** sekmesine gidin. Aşağıdaki değişkenleri ekleyin:

#### Zorunlu Değişkenler:
```
JWT_SECRET=<güçlü_rastgele_string>
ADMIN_USERNAME=admin
ADMIN_PASSWORD=<güçlü_şifre>
```

#### Opsiyonel Değişkenler (Özelliklere göre):
```
DETECTION_RADIUS_METERS=50
ADMIN_EMAIL=admin@example.com
JWT_EXPIRE_MIN=1440
OTP_TTL_SECONDS=300
OTP_CODE_LEN=6
PENALTY_COOLDOWN_SEC=180
RATE_LIMIT_WINDOW_SEC=10
RATE_LIMIT_MAX_REQ=10
```

#### SMTP (Email bildirimleri için):
```
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=your_email@gmail.com
SMTP_PASS=your_app_password
```

#### Twilio (SMS OTP için):
```
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_FROM_NUMBER=+1234567890
TWILIO_MESSAGING_SERVICE_SID=your_messaging_service_sid
```

**NOT**: `DATABASE_URL` değişkeni Railway tarafından otomatik olarak eklenir, manuel eklemenize gerek yok.

### Adım 5: Build ve Deploy Ayarları

1. Web servisinizi seçin
2. **"Settings"** sekmesine gidin
3. **"Build Command"** bölümünde (eğer varsa) boş bırakın - Dockerfile kullanıyoruz
4. **"Start Command"** bölümünde:
   ```
   uvicorn app.main:app --host 0.0.0.0 --port $PORT
   ```
   (Bu zaten `railway.json` dosyasında tanımlı)

### Adım 6: Domain Ayarlama (Opsiyonel)

1. Web servisinizi seçin
2. **"Settings"** sekmesine gidin
3. **"Generate Domain"** butonuna tıklayın
4. Railway size otomatik bir domain verecek (örn: `your-project.up.railway.app`)
5. Özel domain eklemek isterseniz **"Custom Domain"** bölümünden ekleyebilirsiniz

### Adım 7: Deploy

1. Railway otomatik olarak kodunuzu deploy edecek
2. **"Deployments"** sekmesinden deploy durumunu takip edebilirsiniz
3. Build tamamlandıktan sonra servisiniz canlıya alınacak

## 🔧 Veritabanı Schema Kurulumu

Railway'de PostgreSQL servisi oluşturulduktan sonra, veritabanı şemasını kurmanız gerekiyor:

### Yöntem 1: Railway CLI ile (Önerilen)

1. Railway CLI'yi yükleyin:
   ```bash
   npm i -g @railway/cli
   ```

2. Railway'e giriş yapın:
   ```bash
   railway login
   ```

3. Projenizi seçin:
   ```bash
   railway link
   ```

4. Veritabanı şemasını çalıştırın:
   ```bash
   railway connect postgres < backend/app/models.sql
   ```
   
   Veya psql ile:
   ```bash
   railway connect postgres
   ```
   Sonra psql içinde:
   ```sql
   \i backend/app/models.sql
   ```

### Yöntem 2: Railway Dashboard'dan

1. PostgreSQL servisinizi seçin
2. **"Connect"** sekmesine gidin
3. **"Query"** sekmesine tıklayın
4. `backend/app/models.sql` dosyasının içeriğini kopyalayıp yapıştırın ve çalıştırın

## ✅ Deployment Sonrası Kontroller

1. **Servis Durumu**: Dashboard'da servisinizin "Active" olduğunu kontrol edin
2. **Loglar**: **"Deployments"** → **"View Logs"** ile logları kontrol edin
3. **API Test**: Domain'inizi tarayıcıda açın ve `/api/zones` endpoint'ini test edin
4. **Admin Panel**: `/admin` sayfasına gidin ve admin girişi yapın

## 🔍 Sorun Giderme

### Build Hatası
- **Sorun**: Dockerfile build hatası
- **Çözüm**: Railway build loglarını kontrol edin. Frontend dosyalarının doğru kopyalandığından emin olun

### Veritabanı Bağlantı Hatası
- **Sorun**: "Connection refused" veya "Database not found"
- **Çözüm**: 
  - `DATABASE_URL` değişkeninin otomatik olarak eklendiğini kontrol edin
  - PostgreSQL servisinin "Active" olduğunu kontrol edin
  - Web servisinin PostgreSQL servisine bağlı olduğunu kontrol edin (Settings → Service Dependencies)

### Port Hatası
- **Sorun**: "Port already in use"
- **Çözüm**: Railway otomatik olarak `PORT` değişkenini ayarlar. Kodunuzda `$PORT` kullandığınızdan emin olun

### Static Files Hatası
- **Sorun**: Frontend dosyaları yüklenmiyor
- **Çözüm**: Dockerfile'da frontend dosyalarının doğru kopyalandığını kontrol edin

## 📝 Önemli Notlar

1. **DATABASE_URL**: Railway otomatik olarak bu değişkeni sağlar. Manuel eklemenize gerek yok.
2. **PORT**: Railway otomatik olarak port atar. Kodunuzda `$PORT` veya `os.getenv('PORT')` kullanın.
3. **HTTPS**: Railway otomatik olarak HTTPS sağlar. Ekstra SSL yapılandırmasına gerek yok.
4. **Environment Variables**: Hassas bilgileri (şifreler, API key'ler) environment variables olarak saklayın.
5. **PostGIS Extension**: Veritabanı şemasında PostGIS extension'ı otomatik olarak kurulur.

## 🔄 Güncelleme

Kodunuzu güncellediğinizde:
1. GitHub'a push edin
2. Railway otomatik olarak yeni bir deploy başlatacak
3. Deploy tamamlandıktan sonra değişiklikler canlıya alınacak

## 📞 Destek

Sorun yaşarsanız:
- Railway dashboard'daki logları kontrol edin
- Railway dokümantasyonunu inceleyin: https://docs.railway.app
- Railway Discord topluluğuna katılın

