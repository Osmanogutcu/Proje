/**
 * Akıllı Hız Sistemi - Demo Server (Fly.io uyumlu, DB'siz)
 * - HTTP (Fly) / HTTPS (local)
 * - /speed-points: EDS/Radar noktaları (JSON)
 * - /telemetry: cihazdan konum gönderimi
 * - /admin/login, /admin/violations, /admin/devices
 * - WebSocket: /ws (canlı akış)
 */

const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");
const express = require("express");
const cors = require("cors");
const WebSocket = require("ws");
const crypto = require("crypto");

const app = express();
app.use(cors());
app.use(express.json({ limit: "2mb" }));

// ---------- ENV / MODES ----------
const IS_FLY = !!process.env.FLY_APP_NAME || process.env.NODE_ENV === "production";
const HOST = "0.0.0.0";
const PORT = Number(process.env.PORT || 3000);

const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "admin123"; // Fly secrets ile değiştir

// Basit token
const ADMIN_TOKEN_TTL_MS = 1000 * 60 * 60 * 6; // 6 saat
const adminTokens = new Map(); // token -> { exp }

// OTP (demo)
const OTP_TTL_MS = 1000 * 60 * 5; // 5 dk
const otpStore = new Map(); // phone -> { code, exp, device_id }

// ---------- IN-MEM STORE ----------
const db = {
  devices: new Map(), // device_id -> { device_id, phone, lastSeen, lastLat, lastLon, lastSpeedKmh }
  tracks: new Map(),  // device_id -> [{t, lat, lon, acc, speedKmh}]
  violations: [],     // [{id, t, device_id, phone, region, speedKmh, limitKmh, overKmh, lat, lon, notifiedAt}]
  speedPoints: [],    // [{id, name, lat, lon, limitKmh, radiusM}]
};

// ---------- HELPERS ----------
function nowIso() {
  return new Date().toISOString();
}

function randToken(n = 32) {
  return crypto.randomBytes(n).toString("hex");
}

function requireAdmin(req, res, next) {
  const h = req.headers.authorization || "";
  const tok = h.startsWith("Bearer ") ? h.slice(7) : "";
  const info = adminTokens.get(tok);
  if (!info) return res.status(401).json({ error: "unauthorized" });
  if (Date.now() > info.exp) {
    adminTokens.delete(tok);
    return res.status(401).json({ error: "expired" });
  }
  next();
}

function haversineMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = (x) => (x * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function computeSpeedKmh(prev, cur) {
  // prev/cur: {t(ms), lat, lon}
  const dt = (cur.t - prev.t) / 1000;
  if (dt <= 0) return 0;
  const d = haversineMeters(prev.lat, prev.lon, cur.lat, cur.lon);
  const mps = d / dt;
  return mps * 3.6;
}

function nearestRadar(lat, lon) {
  let best = null;
  for (const p of db.speedPoints) {
    const d = haversineMeters(lat, lon, p.lat, p.lon);
    if (d <= p.radiusM) {
      if (!best || d < best.distanceM) best = { ...p, distanceM: d };
    }
  }
  return best;
}

function seedSpeedPointsOnce() {
  if (db.speedPoints.length) return;

  // Kullanıcının verdiği EDS koordinatları (10 adet olacak şekilde)
  // 9 nokta + 1 yakın ek nokta
  const points = [
    { name: "EDS-1",  lat: 38.6813888889, lon: 39.2002222222, limitKmh: 50, radiusM: 120 },
    { name: "EDS-2",  lat: 38.6791388889, lon: 39.1987500000, limitKmh: 50, radiusM: 120 },
    { name: "EDS-3",  lat: 38.6777222222, lon: 39.2045555556, limitKmh: 50, radiusM: 120 },
    { name: "EDS-4",  lat: 38.6820833333, lon: 39.2153888889, limitKmh: 50, radiusM: 140 },
    { name: "EDS-5",  lat: 38.6748333333, lon: 39.2228055556, limitKmh: 50, radiusM: 140 },
    { name: "EDS-6",  lat: 38.6750833333, lon: 39.2195277778, limitKmh: 50, radiusM: 140 },
    { name: "EDS-7",  lat: 38.6744444444, lon: 39.2051111111, limitKmh: 50, radiusM: 130 },
    { name: "EDS-8",  lat: 38.6796111111, lon: 39.2539722222, limitKmh: 70, radiusM: 160 },
    { name: "EDS-9",  lat: 38.6754166667, lon: 39.1988333333, limitKmh: 50, radiusM: 120 },
    // 10. tamamlayıcı (aynı şehir içi hat üzerinde yakın bir nokta)
    { name: "EDS-10", lat: 38.6809000000, lon: 39.2100000000, limitKmh: 50, radiusM: 140 },
  ];

  db.speedPoints = points.map((p, i) => ({
    id: i + 1,
    ...p,
  }));

  console.log("[*] Demo speed_points eklendi (memory).");
}

// ---------- STATIC FRONTEND ----------
const frontendDir = path.join(__dirname, "..", "frontend");
app.use(express.static(frontendDir));

// default
app.get("/", (req, res) => res.redirect("/tracker.html"));

// ---------- API ----------
app.get("/health", (req, res) => res.json({ ok: true, t: nowIso(), fly: IS_FLY, port: PORT }));

// Radar / EDS noktaları
app.get("/speed-points", (req, res) => {
  seedSpeedPointsOnce();
  res.json(db.speedPoints);
});

// OTP - demo (SMS yok, sadece code üretir)
app.post("/otp/request", (req, res) => {
  const { device_id, phone } = req.body || {};
  if (!device_id || !phone) return res.status(400).json({ error: "device_id ve phone zorunlu" });

  const code = String(Math.floor(100000 + Math.random() * 900000));
  otpStore.set(phone, { code, exp: Date.now() + OTP_TTL_MS, device_id });

  // Demo: code'u response ile dön (sunum için)
  res.json({ ok: true, demo_code: code });
});

app.post("/otp/verify", (req, res) => {
  const { phone, code, device_id } = req.body || {};
  const item = otpStore.get(phone);
  if (!item) return res.status(400).json({ error: "otp_not_found" });
  if (Date.now() > item.exp) return res.status(400).json({ error: "otp_expired" });
  if (String(code) !== String(item.code)) return res.status(400).json({ error: "otp_invalid" });
  if (String(device_id) !== String(item.device_id)) return res.status(400).json({ error: "device_mismatch" });

  // device kaydı
  const d = db.devices.get(device_id) || { device_id };
  d.phone = phone;
  d.lastSeen = Date.now();
  db.devices.set(device_id, d);

  // cihaz token
  const token = randToken(16);
  res.json({ ok: true, token });
});

// Telemetry (cihazdan konum)
app.post("/telemetry", (req, res) => {
  seedSpeedPointsOnce();

  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  // demo: token boşsa bile reject et (senin akışın böyle)
  if (!token) return res.status(401).json({ error: "invalid_token" });

  const { device_id, phone, lat, lon, acc } = req.body || {};
  if (!device_id || typeof lat !== "number" || typeof lon !== "number") {
    return res.status(400).json({ error: "device_id, lat, lon zorunlu" });
  }

  // device güncelle
  const dev = db.devices.get(device_id) || { device_id };
  if (phone) dev.phone = phone;
  dev.lastSeen = Date.now();
  dev.lastLat = lat;
  dev.lastLon = lon;
  db.devices.set(device_id, dev);

  // track ekle
  const tNow = Date.now();
  const arr = db.tracks.get(device_id) || [];
  const cur = { t: tNow, lat, lon, acc: acc ?? null };

  let speedKmh = 0;
  const prev = arr.length ? arr[arr.length - 1] : null;
  if (prev) {
    speedKmh = computeSpeedKmh({ t: prev.t, lat: prev.lat, lon: prev.lon }, { t: cur.t, lat: cur.lat, lon: cur.lon });
  }
  cur.speedKmh = speedKmh;
  arr.push(cur);
  if (arr.length > 2000) arr.shift();
  db.tracks.set(device_id, arr);

  dev.lastSpeedKmh = speedKmh;

  // radar kontrol
  const radar = nearestRadar(lat, lon);
  let violation = null;
  let insideRadar = false;

  if (radar) {
    insideRadar = true;
    const limitKmh = radar.limitKmh;
    if (speedKmh > limitKmh + 1) {
      const over = speedKmh - limitKmh;
      violation = {
        id: db.violations.length + 1,
        t: nowIso(),
        device_id,
        phone: dev.phone || phone || "",
        region: radar.name,
        speedKmh: Number(speedKmh.toFixed(1)),
        limitKmh,
        overKmh: Number(over.toFixed(1)),
        lat,
        lon,
        notifiedAt: null,
      };
      db.violations.unshift(violation);
      if (db.violations.length > 2000) db.violations.pop();
    }
  }

  // WS publish
  wsBroadcast({
    type: "telemetry",
    device_id,
    phone: dev.phone || "",
    lat,
    lon,
    speedKmh: Number(speedKmh.toFixed(1)),
    acc: acc ?? null,
    insideRadar,
    radar: radar ? { id: radar.id, name: radar.name, limitKmh: radar.limitKmh, radiusM: radar.radiusM } : null,
  });

  if (violation) {
    wsBroadcast({ type: "violation", violation });
  }

  res.json({
    ok: true,
    speedKmh: Number(speedKmh.toFixed(1)),
    insideRadar,
    radarName: radar ? radar.name : null,
    violation,
  });
});

// ---------- ADMIN ----------
app.post("/admin/login", (req, res) => {
  const { username, password } = req.body || {};
  if (username !== ADMIN_USER || password !== ADMIN_PASS) {
    return res.status(401).json({ error: "invalid_credentials" });
  }
  const token = randToken(16);
  adminTokens.set(token, { exp: Date.now() + ADMIN_TOKEN_TTL_MS });
  res.json({ ok: true, token });
});

app.get("/admin/violations", requireAdmin, (req, res) => {
  res.json(db.violations);
});

app.get("/admin/devices", requireAdmin, (req, res) => {
  const out = [];
  for (const d of db.devices.values()) {
    const age = Date.now() - (d.lastSeen || 0);
    out.push({
      device_id: d.device_id,
      phone: d.phone || "",
      lastSeen: d.lastSeen || null,
      online: age < 1000 * 20, // 20 sn
      lat: d.lastLat ?? null,
      lon: d.lastLon ?? null,
      speedKmh: d.lastSpeedKmh ?? 0,
    });
  }
  // son görülen önce
  out.sort((a, b) => (b.lastSeen || 0) - (a.lastSeen || 0));
  res.json(out);
});

// demo bildirim (buton için)
app.post("/admin/notify", requireAdmin, (req, res) => {
  const { violation_id } = req.body || {};
  const v = db.violations.find((x) => x.id === Number(violation_id));
  if (!v) return res.status(404).json({ error: "not_found" });
  if (v.notifiedAt) return res.status(409).json({ error: "already_notified" });

  v.notifiedAt = nowIso();
  wsBroadcast({ type: "notified", violation: v });
  res.json({ ok: true });
});

// ---------- WS ----------
let wss = null;
function wsBroadcast(obj) {
  if (!wss) return;
  const msg = JSON.stringify(obj);
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) client.send(msg);
  }
}

function attachWebSocket(server) {
  wss = new WebSocket.Server({ noServer: true });

  server.on("upgrade", (req, socket, head) => {
    const url = req.url || "";
    if (!url.startsWith("/ws")) return;
    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req);
    });
  });

  wss.on("connection", (ws) => {
    ws.send(JSON.stringify({ type: "hello", t: nowIso() }));
  });

  console.log("[*] WS hazır: /ws");
}

// ---------- START SERVER ----------
seedSpeedPointsOnce();

if (IS_FLY) {
  // Fly: HTTP (TLS'yi fly-proxy yapar)
  const server = http.createServer(app);
  attachWebSocket(server);
  server.listen(PORT, HOST, () => {
    console.log(`[*] HTTP API dinlemede: http://0.0.0.0:${PORT}`);
    console.log(`    tracker: /tracker.html  |  admin: /admin.html`);
    console.log(`    ws: /ws (wss://<domain>/ws)`);
  });
} else {
  // Local: HTTPS (geolocation için)
  const certDir = path.join(__dirname, "cert");
  const keyPath = path.join(certDir, "localhost-key.pem");
  const certPath = path.join(certDir, "localhost-cert.pem");

  if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
    console.log("[!] Local HTTPS sertifikaları yok: hiz-backend/cert/localhost-*.pem");
    console.log("    Sunum için Fly domain kullan veya sertifika üret.");
    process.exit(1);
  }

  const httpsOptions = {
    key: fs.readFileSync(keyPath),
    cert: fs.readFileSync(certPath),
  };

  const httpsServer = https.createServer(httpsOptions, app);
  attachWebSocket(httpsServer);

  httpsServer.listen(PORT, HOST, () => {
    console.log(`[*] HTTPS API dinlemede: https://<PC-IP>:${PORT}`);
    console.log("    tracker: /tracker.html  |  admin: /admin.html");
    console.log(`    ws: /ws (wss://<PC-IP>:${PORT}/ws)`);
  });
}
