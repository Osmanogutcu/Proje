// db.js
const { Pool } = require("pg");

const pool = new Pool({
  host: "localhost",
  port: 5432,
  user: "postgres",         // kendi kullanıcı adın
  password: "postgres",     // kendi şifren
  database: "hizsistemi"
});

module.exports = {
  query: (text, params) => pool.query(text, params),
  pool
};
