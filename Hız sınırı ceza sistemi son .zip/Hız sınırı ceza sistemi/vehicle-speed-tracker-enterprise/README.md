# Vehicle Speed Tracker ENTERPRISE
FastAPI + PostgreSQL **PostGIS** + Leaflet + WebSocket + **Nginx HTTPS** + **SMS OTP (Twilio)** + **CSV/PDF** raporlar.

## Neler eklendi?
- **PostGIS geçişi**: `speed_points` ve `track_points` için `geography(Point,4326)`; **GiST** index ve metre bazlı `ST_DWithin`.
- **Nginx reverse proxy + HTTPS**: HSTS, CSP, X-Frame-Options, X-Content-Type-Options; WebSocket uyumlu. (Self-signed örnek; prod’da Let’s Encrypt önerilir)
- **SMS OTP doğrulama (Twilio)**: `/api/device/request_otp` ve `/api/device/verify_otp`. `devices.phone_verified` ile işaretlenir.
- **Arşiv/Rapor**: `/api/admin/report/daily.csv`, `/api/admin/report/weekly.csv`, `/api/admin/report/daily.pdf`, `/api/admin/report/weekly.pdf`

## Hızlı kurulum
1. `.env.example` → `.env` kopyala ve doldur (DB şifreleri, SMTP, **Twilio**, JWT, vb.).  
2. Çalıştır:
   ```bash
   docker-compose up --build
   ```
3. Prod’a uygun https:
   - `nginx/ssl` altında **self-signed** örnek var. Prod’da Let’s Encrypt için `nginx/conf.d/app.conf` içinde sertifika yollarını güncelleyin.

### URL’ler
- HTTPS reverse proxy: `https://localhost/`
  - Kullanıcı: `/`
  - Admin: `/admin`
  - Tracker (PWA): `/tracker`

## Notlar
- Local HTTPS için tarayıcı self-signed sertifikayı güvensiz görebilir; prod’da Let’s Encrypt kullanın.
- CORS: reverse proxy aynı origin verdiğinden kapalı tutuldu. Dış origin gerekiyorsa `nginx/conf.d/app.conf` içindeki CORS bloklarını açın.
